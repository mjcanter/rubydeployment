class UsersController < ApplicationController
	before_action :check_session
  def index
  	@user = User.find_by_id(session[:user_id])
  	@secrectsown = Secret.where(user_id: session[:user_id])
  	@secretslike = Secret.joins(:likes).where(index_likes_on_user_id: session[:user_id])


  end
  def delete
  	User.find(params[:id]).destroy
  	redirect_to '/sessions'
  end
  def edit
  	user = User.update(user_params)

  	if User.valid?
  		redirect_to '/users'
  	else
  		redirect_to '/edit'
  		flash[:error] = @message.errors
    end
  end  
  private

  def check_session
  	if !session[:user_id]
  		redirect_to '/'
    end
  end
  def user_params
  	params.require(:user).permit(:name,:email, :password, :password_confirmation)
  end
end
